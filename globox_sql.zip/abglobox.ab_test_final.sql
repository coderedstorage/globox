CREATE OR REPLACE VIEW abglobox.ab_test_final AS
WITH countries AS
(SELECT simple_name country_name, alpha_3_code country FROM abglobox.iso_codes),
activity AS 
(SELECT DISTINCT
    uid user_id,
    device,
    COUNT(*) activity_records,
    MIN(dt) first_purchase_dt,
    MAX(dt) last_purchase_dt,
    COUNT(DISTINCT dt) purchase_days,
    SUM(spent) spend_amt,
    COUNT(DISTINCT spent) unique_basket_count,
    AVG(spent) avg_basket_size,
    MAX(spent) max_basket_size,
    MIN(spent) min_basket_size,
    MAX(spent) = MIN(spent) max_vs_min_basket
FROM
    abglobox.activity
GROUP BY 1 , 2),
detail AS
(SELECT 
    u.id user_id,
    IF(u.country IS NULL OR u.country = '',
        'unknown',
        u.country) country,
    u.country IN (SELECT 
            country
        FROM
            countries) country_known,
    COALESCE(c.country_name, 'unknown') country_name,
    IF(u.gender IS NULL OR u.gender = '',
        'unknown',
        u.gender) gender,
    CASE
        WHEN g.group = 'A' THEN 'A: control'
        WHEN g.group = 'B' THEN 'B: treatment'
        ELSE 'potential_issue'
    END test_group,
    g.join_dt,
    a.first_purchase_dt,
    a.last_purchase_dt,
    COALESCE(a.first_purchase_dt, g.join_dt) first_active_dt,
    COALESCE(a.last_purchase_dt,
            a.first_purchase_dt,
            g.join_dt) last_active_dt,
    IF(g.device IS NULL OR g.device = '',
        'unknown',
        g.device) join_device,
    IF(a.device IS NULL OR a.device = '',
        'unknown',
        a.device) active_device,
    IF((g.device = a.device) IS NULL,
        0,
        (g.device = a.device)) device_consistent,
    COALESCE(NULLIF(a.device, ''),
            NULLIF(g.device, ''),
            'unknown') device,
    CASE
        WHEN
            (a.user_id IS NOT NULL
                AND a.spend_amt > 0)
        THEN
            1
        ELSE 0
    END conversion,
    IFNULL(a.activity_records, 0) activity_records,
    IFNULL(a.purchase_days, 0) purchase_days,
    IFNULL(a.spend_amt, 0) spend_amt,
    IFNULL(a.unique_basket_count, 0) unique_basket_count,
    IFNULL(a.avg_basket_size, 0) avg_basket_size,
    IFNULL(a.max_basket_size, 0) max_basket_size,
    IFNULL(a.min_basket_size, 0) min_basket_size
FROM
    abglobox.users u
        LEFT JOIN
    countries c ON u.country = c.country
        LEFT JOIN
    abglobox.groups g ON u.id = g.uid
        LEFT JOIN
    activity a ON u.id = a.user_id)

SELECT 
user_id, 
country_name, 
CASE WHEN gender = 'M' THEN 'Male' WHEN gender = 'F' THEN 'Female' WHEN gender = 'O' THEN 'Other' ELSE 'unknown' END gender, 
test_group, 
conversion conversion, 
spend_amt spend_USD, 
CASE WHEN device = 'I' THEN 'iOS' WHEN device = 'A' THEN 'Android' ELSE 'unknown'END device,
join_dt,
first_active_dt,
last_active_dt,
purchase_days,
DATEDIFF(last_active_dt, join_dt)+1 user_lifespan_days,
CASE WHEN conversion = 1 THEN DATEDIFF(first_active_dt, join_dt)+1 ELSE "no conversion" END days_to_convert,
CASE WHEN conversion = 1 THEN DATEDIFF(last_active_dt, first_active_dt)+1 ELSE "no conversion" END user_active_lifespan_days,
DATE_FORMAT(join_dt, '%b-%Y') cohort_month,
DATE_FORMAT(join_dt, '%X: Week %V') cohort_week,
CASE WHEN spend_amt > 200 THEN 'Y' ELSE 'N' END 'spend_USD_200_plus',
CASE WHEN country_name IN ('Australia', "United Kingdom", 'USA', 'Canada') THEN 'Y' 
WHEN country_name = 'unknown' THEN country_name ELSE 'N' END anglophone,
CURRENT_TIMESTAMP run_time
FROM detail;