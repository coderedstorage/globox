CREATE OR REPLACE VIEW abglobox.ab_lifecycle AS
WITH lifecycle AS
(SELECT a.join_dt lifecycle_date, +1 user_join, 0 user_exit, a.* FROM abglobox.ab_test_final a
UNION ALL
SELECT b.last_active_dt lifecycle_date, 0 user_join, -1 user_exit, b.* FROM abglobox.ab_test_final b)

SELECT 
    lifecycle_date,
    gender,
    device,
    country_name,
    test_group,
    conversion,
    join_dt,
    last_active_dt,
    days_to_convert,
    purchase_days,
    user_lifespan_days lifespan,
    user_active_lifespan_days active_lifespan,
    spend_USD_200_plus,
    cohort_month,
    cohort_week,
    anglophone,
    SUM(user_join) num_user_joins,
    SUM(user_exit) num_user_exits
FROM
    lifecycle
    GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16
    ORDER BY 1;
