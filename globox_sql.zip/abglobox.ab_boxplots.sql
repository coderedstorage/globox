CREATE OR REPLACE VIEW abglobox.ab_boxplots AS
WITH ab_data AS (SELECT * FROM abglobox.ab_test_final) 
(SELECT 'overall' scope, user_id, anglophone, conversion, spend_USD, test_group, spend_USD_200_plus "$200+" FROM ab_data)
Union all
(SELECT '$200_or_less' scope, user_id, anglophone, conversion, spend_USD, test_group, spend_USD_200_plus "$200+"  FROM ab_data WHERE spend_USD_200_plus = 'N')
union all
(SELECT 'android' scope, user_id, anglophone, conversion, spend_USD, test_group, spend_USD_200_plus "$200+" FROM ab_data WHERE device = 'Android')
Union all
(SELECT 'ios' scope, user_id, anglophone, conversion, spend_USD, test_group, spend_USD_200_plus "$200+" FROM ab_data WHERE device = 'ios')
Union all
(SELECT 'male' scope, user_id, anglophone, conversion, spend_USD, test_group, spend_USD_200_plus "$200+" FROM ab_data WHERE gender = 'male')
Union all
(SELECT 'female' scope, user_id, anglophone, conversion, spend_USD, test_group, spend_USD_200_plus "$200+" FROM ab_data WHERE gender = 'female')
Union all
(SELECT 'USA' scope, user_id, anglophone, conversion, spend_USD, test_group, spend_USD_200_plus "$200+" FROM ab_data WHERE country_name = 'USA')
Union all
(SELECT 'mexico' scope, user_id, anglophone, conversion, spend_USD, test_group, spend_USD_200_plus "$200+" FROM ab_data WHERE country_name = 'Mexico')
Union all
(SELECT 'germany' scope, user_id, anglophone, conversion, spend_USD, test_group, spend_USD_200_plus "$200+" FROM ab_data WHERE country_name = 'Germany')